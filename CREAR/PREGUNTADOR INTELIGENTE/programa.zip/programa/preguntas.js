const titulo_del_juego = "MICROORGANISMOS";

const preguntas = [
  { pregunta: "MICROORGANISMOS", respuesta: "Seres vivos. La mayoría unicelulares y algunos pluricelulares, que sólo son visibles al microscopio. También se les llama microbios.", palabrasclave: "vivos,unicelulares,pluricelulares,microscopio,microbios" },
  { pregunta: "TIPOS DE MICROORGANISMOS", respuesta: "Son cinco. En orden alfabético: Algas unicelulares,bacterias,levaduras,mohos y protozoos", palabrasclave: "algas,bacterias,levaduras,mohos,protozoos" },
  { pregunta: "MICROORGANISMOS PATOGENOS", respuesta: "Son aquellos que producen enfermedades. Las enfermedades que producen se llaman enfermedades infecciosas y al microorganismo que causa la enfermedad se le llama agente patógeno.", palabrasclave: "infecciosas,patogeno" },
  { pregunta: "EJEMPLOS DE ENFERMEDADES CAUSADAS POR MICROORGANISMOS PATOGENOS", respuesta: "Tuberculosis y cólera, causados por bacterias\nMalaria y enfermedad del sueño, causados por protozoos\nPie de atleta y candidiasis, causado por hongos", palabrasclave: "tuberculosis,colera,malaria,sueño,atleta,candidiasis" },
  { pregunta: "MICROORGANISMOS BENEFICIOSOS", respuesta: "La mayoría de los microorganismos son beneficiosos, tanto para el ser humano, como para el medio ambiente.", palabrasclave: "humano,ambiente" },
  { pregunta: "TIPOS DE MICROORGANISMOS BENEFICIOSOS", respuesta: "Hay dos tipos:\n-Productores, producen materia orgánica(algunas bacterias y algas)\n-Descomponedores, descomponen materia orgánica en inorgánica(algunas bacterias, mohos y levaduras)", palabrasclave: "productores,bacterias,algas,descomponedores,mohos,levaduras" }
];

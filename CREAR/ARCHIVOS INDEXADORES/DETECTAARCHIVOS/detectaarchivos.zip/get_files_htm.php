<?php
$files = scandir(__DIR__);

foreach ($files as $file) {
    if (pathinfo($file, PATHINFO_EXTENSION) === 'htm') {
        echo $file . "\n";
    }
}
?>

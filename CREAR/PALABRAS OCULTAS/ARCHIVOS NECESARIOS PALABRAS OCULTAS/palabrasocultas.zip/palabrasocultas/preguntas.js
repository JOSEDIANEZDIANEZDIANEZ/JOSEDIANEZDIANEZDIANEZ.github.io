var text = `Artículo 9 . 
1 .  Los ciudadanos y los poderes públicos están sujetos a la Constitución y al resto del ordenamiento jurídico . 
2 .  Corresponde a los poderes públicos promover las condiciones 
para que la libertad y la igualdad del individuo y de los grupos en que 
se integra sean reales y efectivas; remover los obstáculos que impidan o dificulten su plenitud y facilitar la participación de todos los 
ciudadanos en la vida política ,  económica ,  cultural y social . 
3 .  La Constitución garantiza el principio de legalidad ,  la jerarquía 
normativa ,  la publicidad de las normas ,  la irretroactividad de las disposiciones sancionadoras no favorables o restrictivas de derechos 
individuales ,  la seguridad jurídica ,  la responsabilidad y la interdicción de la arbitrariedad de los poderes públicos . `;
var keywords = ["Artículo","ciudadanos","poderes","públicos","ordenamiento","Corresponde","impidan","principio","legalidad","jerarquía","individuales","seguridad","responsabilidad",""];
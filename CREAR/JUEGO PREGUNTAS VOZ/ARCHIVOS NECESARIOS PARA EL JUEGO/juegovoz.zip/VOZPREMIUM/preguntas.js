var nombreDelJuego = "";

var absolutamentetodaslaspreguntas = [];
